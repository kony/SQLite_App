function AS_Button_f6ecd51287f4454a95e30a9cd7a21845(eventobject) {
    return transaction.call(this);
}