function addWidgetsMainForm() {
    MainForm.setDefaultUnit(kony.flex.DP);
    var FlexContainer01 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "552dp",
        "id": "FlexContainer01",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "skin": "CopyslFbox0469c4754b7e94d",
        "top": "0dp",
        "width": "100.00%"
    }, {}, {});
    FlexContainer01.setDefaultUnit(kony.flex.DP);
    var IDLabel = new kony.ui.Label({
        "id": "IDLabel",
        "isVisible": true,
        "left": "12dp",
        "skin": "CopyslLabel0c79509539fc044",
        "text": "ID",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "63dp",
        "width": kony.flex.USE_PREFFERED_SIZE
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var NameLabel = new kony.ui.Label({
        "id": "NameLabel",
        "isVisible": true,
        "left": "11dp",
        "skin": "CopyslLabel0f44eef9d186e42",
        "text": "Name",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "113dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var DepartmentLabel = new kony.ui.Label({
        "id": "DepartmentLabel",
        "isVisible": true,
        "left": "12dp",
        "skin": "CopyslLabel0bcb11c46869743",
        "text": "Department",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "168dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var IDTextBox = new kony.ui.TextBox2({
        "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
        "height": "40dp",
        "id": "IDTextBox",
        "isVisible": true,
        "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
        "left": "135dp",
        "secureTextEntry": false,
        "skin": "slTextBox",
        "text": "Employee ID",
        "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
        "top": "55dp",
        "width": "180dp",
        "zIndex": 1
    }, {
        "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [3, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "autoFilter": false,
        "keyboardActionLabel": constants.TEXTBOX_KEYBOARD_LABEL_DEFAULT,
        "viewType": constants.TEXTBOX_VIEW_TYPE_DEFAULT
    });
    var NameTextBox = new kony.ui.TextBox2({
        "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
        "height": "40dp",
        "id": "NameTextBox",
        "isVisible": true,
        "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
        "left": "135dp",
        "secureTextEntry": false,
        "skin": "slTextBox",
        "text": "Employee Name",
        "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
        "top": "105dp",
        "width": "180dp",
        "zIndex": 1
    }, {
        "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [3, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "autoFilter": false,
        "keyboardActionLabel": constants.TEXTBOX_KEYBOARD_LABEL_DEFAULT,
        "viewType": constants.TEXTBOX_VIEW_TYPE_DEFAULT
    });
    var DepartmentTextBox = new kony.ui.TextBox2({
        "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
        "height": "40dp",
        "id": "DepartmentTextBox",
        "isVisible": true,
        "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
        "left": "135dp",
        "secureTextEntry": false,
        "skin": "slTextBox",
        "text": "Department ID",
        "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
        "top": "156dp",
        "width": "180dp",
        "zIndex": 1
    }, {
        "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [3, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "autoFilter": false,
        "keyboardActionLabel": constants.TEXTBOX_KEYBOARD_LABEL_DEFAULT,
        "viewType": constants.TEXTBOX_VIEW_TYPE_DEFAULT
    });
    var AddButton = new kony.ui.Button({
        "focusSkin": "slButtonGlossRed",
        "height": "50dp",
        "id": "AddButton",
        "isVisible": true,
        "left": "52dp",
        "onClick": AS_Button_f6ecd51287f4454a95e30a9cd7a21845,
        "skin": "slButtonGlossBlue",
        "text": "Add",
        "top": "242dp",
        "width": "260dp",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    FlexContainer01.add(
    IDLabel, NameLabel, DepartmentLabel, IDTextBox, NameTextBox, DepartmentTextBox, AddButton);
    MainForm.add(
    FlexContainer01);
};

function MainFormGlobals() {
    MainForm = new kony.ui.Form2({
        "addWidgets": addWidgetsMainForm,
        "enabledForIdleTimeout": false,
        "id": "MainForm",
        "init": AS_Form_4379b36565784d28b582be30be15120e,
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": true,
        "postShow": AS_Form_9b1dca07755a41028637868153054674,
        "skin": "slForm"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "footerOverlap": false,
        "headerOverlap": false,
        "menuPosition": constants.FORM_MENU_POSITION_AFTER_APPMENU,
        "retainScrollPosition": false,
        "titleBar": true,
        "titleBarSkin": "slTitleBar",
        "windowSoftInputMode": constants.FORM_ADJUST_RESIZE
    });
    MainForm.info = {
        "kuid": "82646580f601441890be80633f4e6276"
    };
};